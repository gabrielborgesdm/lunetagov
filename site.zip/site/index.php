<?php
	$controle = "index";
	include("cabecalho.php");
?>
	<div id="adbox">
		<div class="clearfix">
			<img src="images/box.png" alt="Img" height="342" width="368">
			<div>
				<h2>Você já se perguntou para onde está indo o dinheiro público do seu estado?</h2>
				</br>
				<p>Ainda não sabe?</p>
				<p>Por acaso você já ouviu falar sobre Portais de Transparência?
				</br>
				<p>
					<span><a href="consultas.php" class="btn">Veja agora!</a></span>
				</p>
			</div>
		</div>
	</div>
	
	
	
<?php
	include("rodape.php");
?>