
    
  
    <form name="cadastro_usuario" method="post" class="message" action="cadastrar_usuario.php">
      
      
        
          Nome: <input type="text" name="nome" /> <br />
          E-mail: <input type="email" name="email" /> <br />
          Senha: <input type="password" name="senha" /> <br />
          Estado: <input type="text" name="estado" /> <br />
          Cidade: <input type="text" name="cidade" />
      
          <input type="button" name="cadastrar" value="Cadastrar" onclick="enviarFormCadastro()"  />
      
    </form> 
    
