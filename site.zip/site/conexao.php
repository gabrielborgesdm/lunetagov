<?php

$conn = new PDO("mysql:host=diadepromocao.com.br;dbname=ddpbr_lunetagov","ddpbr_luneta","123luneta456");

?>